import type { ReactNode } from "react";
import { LandingNav } from "@/components/dashboard/landing/landingNav";
import { muted } from "@/components/dashboard/landing/shared";

export default function LandingLayout({ children }: { children: ReactNode }) {
  return (
    <>
      <header>
        <h1 className="text-xl font-semibold">Landing page</h1>
        <p className={`mt-0.5 text-sm ${muted}`}>
          Atur isi halaman utama website. Setiap bagian punya halamannya sendiri.
        </p>
        <LandingNav />
      </header>
      {children}
    </>
  );
}
