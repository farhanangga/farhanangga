"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { LANDING_BASE, LANDING_SECTIONS } from "./sections";

/** Navigasi antar bagian landing page; bisa digeser horizontal di layar kecil. */
export function LandingNav() {
  const pathname = usePathname();

  return (
    <nav
      aria-label="Bagian landing page"
      className="-mx-1 mt-5 overflow-x-auto border-b border-[color:var(--chip)] pb-3"
    >
      <ul className="flex min-w-max gap-1 px-1">
        {LANDING_SECTIONS.map((s) => {
          const href = `${LANDING_BASE}/${s.slug}`;
          const on = pathname === href || pathname.startsWith(`${href}/`);
          return (
            <li key={s.slug}>
              <Link
                href={href}
                aria-current={on ? "page" : undefined}
                className={`block rounded-full px-4 py-2 text-sm outline-none transition-colors focus-visible:ring-2 focus-visible:ring-current ${
                  on
                    ? "bg-[color:var(--chip)] font-medium"
                    : "text-[color:var(--fg-muted)] hover:bg-[color:var(--chip)]"
                }`}
              >
                {s.label}
              </Link>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}
