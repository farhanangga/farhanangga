import type { ReactNode } from "react";
import { CircleAlert } from "lucide-react";

export type Params = { saved?: string; error?: string };

/* token tema (lihat THEME_CSS di components/dashboard/shared.tsx) */
export const muted = "text-[color:var(--fg-muted)]";

export function CardHead({ title, desc }: { title: string; desc?: string }) {
  return (
    <div className="mb-5">
      <h2 className="font-semibold">{title}</h2>
      {desc && <p className={`mt-0.5 text-sm ${muted}`}>{desc}</p>}
    </div>
  );
}

export function ErrorAlert({ children }: { children: ReactNode }) {
  return (
    <div
      role="alert"
      className="mt-5 flex items-start gap-3 rounded-2xl border border-[#E85B53]/30 bg-[#E85B53]/10 px-4 py-3 text-sm font-medium text-[#E85B53]"
    >
      <CircleAlert size={18} className="mt-px shrink-0" />
      <span>{children}</span>
    </div>
  );
}

/** Pembungkus satu bagian; kini satu bagian = satu halaman, jadi tanpa garis pemisah dan jarak besar. */
export function SectionShell({
  id,
  title,
  desc,
  children,
}: {
  id: string;
  title: string;
  desc: ReactNode;
  children: ReactNode;
}) {
  return (
    <section id={id} className="mt-6">
      <h2 className="text-lg font-semibold">{title}</h2>
      <p className={`mt-0.5 text-sm ${muted}`}>{desc}</p>
      {children}
    </section>
  );
}

export function SectionSkeleton({ label }: { label: string }) {
  const pulse = "animate-pulse motion-reduce:animate-none";
  return (
    <div role="status" aria-busy="true" aria-label={label} className={`mt-6 ${pulse}`}>
      <div className="h-6 w-44 rounded-lg bg-[color:var(--chip)]" />
      <div className="mt-5 h-96 rounded-3xl bg-[color:var(--card)]" />
    </div>
  );
}
